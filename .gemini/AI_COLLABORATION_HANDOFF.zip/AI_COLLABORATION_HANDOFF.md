# CHRONOS LMS - MASTER CONTENT GENERATION HANDOFF

## 🎯 MISSION: HEAVY LIFTING & VOLUME GENERATION
You are the primary content generator for the Chronos LMS. Your mission is to take the "Gold Standard" pedagogical framework and the "Chronos Cyberpunk" aesthetic and build out the remaining curriculum at scale.

**Your Goal:** Finish the gaps in Module 1 and prepare for the massive rollout of Modules 2, 3, and 4.

---

## 🏗️ THE ARCHITECTURAL BLUEPRINT

### 1. The Slide System (React + Tailwind)
Slides must be concise (20-25 per lesson). Every lesson follows this 5-Phase Flow:
- **Phase 1: Hook (Slides 1-4):** Mission briefing, Aria/Kael intro, and the "Why".
- **Phase 2: Context (Slides 5-8):** Real-world metaphors and the "Problem" we are solving.
- **Phase 3: Core (Slides 9-16):** Technical definitions, Terminal examples, and "Error-First" teaching.
- **Phase 4: Practice (Slides 17-21):** Graduated challenges (Easy -> Hard).
- **Phase 5: Closure (Slides 22-25):** Kael's Wisdom, Checklist, and XP Reward.

### 2. The Task System (JSON)
Every lesson **MUST** have exactly **17 coding tasks** in its `.json` file.
- **Tasks 1-5:** Fundamental syntax (Typing/Simple Code).
- **Tasks 6-12:** Functional logic (Operations/Methods).
- **Tasks 13-17:** Integration (Complex programs/Debug challenges).

---

## � THE "TO-DO" LIST (HEAVY LIFTING)

### **IMMEDIATE PRIORITY: Module 1 Completion**
- [ ] **Lesson 02 (Variables):** Generate 17 coding tasks (`public/lessons/lesson_02.json`).
- [ ] **Lesson 04 (Nested Constructions):** Create 20-25 slides (`components/slides/Lesson04NewXX.tsx`) AND 17 coding tasks (`public/lessons/lesson_04.json`).

### **UPCOMING: Module 2 (Logic & Flow)**
- [ ] **Lesson 01 (Input):** Slides + 17 Tasks.
- [ ] **Lesson 02 (If/Else):** Slides + 17 Tasks.
- [ ] **Lesson 03 (Complex Logic):** Slides + 17 Tasks.
- [ ] **Lesson 04 (Nested Logic):** Slides + 17 Tasks.

---

## 🛠️ COMPONENT STANDARDS (MATCH THIS EXACTLY)

### **The Terminal (Code Examples)**
```tsx
import { Terminal, CodeLine } from './Terminal';

<Terminal variant="success" title="Python Execution">
    <CodeLine># Comments are gray by default</CodeLine>
    <CodeLine>x = 10 + (5 * 2)</CodeLine>
    <CodeLine output>20</CodeLine>
</Terminal>
```

### **The Mentors (Character Quotes)**
```tsx
import { CharacterQuote, ProTip, RealWorldExample } from './CharacterQuote';

<CharacterQuote character="aria">Contextual/Real-world metaphor here.</CharacterQuote>
<ProTip>Technical "Under the hood" detail from Kael.</ProTip>
<RealWorldExample>A specific use case like 'Ammunition Counter' or 'Mainframe Hack'.</RealWorldExample>
```

---

## 📜 CRITICAL PROJECT RULES
1. ❌ **STRICT NO F-STRINGS POLICY:** Lessons 1-4 must use concatenation (`+`) or commas. Do NOT use `f"string"`.
2. 🟢 **#53d22d (Chronos Green):** Use this for "Success" and "Mastery" elements.
3. 🔵 **#06b6d4 (Chronos Cyan):** Use this for primary UI and "Tech" elements.
4. 🧠 **Error-First Teaching:** Always show what happens when code *breaks* before showing how to fix it.
5. 🎮 **Gamification:** Every lesson must end with a "Lesson Cleared" trophy slide and XP rewards.

---

## � CURRICULUM ROADMAP (ERA 1)
Finish the following using the established templates:

**Module 1: Python Basics**
- L1: Print & Math (Done)
- L2: Variables (Needs 17 Tasks)
- L3: Strings (Done)
- L4: Nested Constructions (Needs all)

**Module 2: Logic & Flow (The Digital Choice)**
- L1: User Input (`input()`)
- L2: If Statements (`if/else`)
- L3: Logical Operators (`and/or/not`)
- L4: Nested Logic (Elif/Nested If)

---

## � SYSTEM SYNC
When you generate code:
1. Provide the **full TSX/JSON code**.
2. Ensure imports match the `@/components/slides/` or `@/components/lesson/` paths.
3. Keep animations smooth using Tailwind's `animate-pulse` or similar.

We are building a premium, "wow-factor" educational experience. Make every slide look like a high-tech terminal interface!
